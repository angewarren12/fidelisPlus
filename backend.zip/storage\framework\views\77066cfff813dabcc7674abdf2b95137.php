<!DOCTYPE html>
<html>
<head>
    <title>Votre devis <?php echo e($quote->quote_number); ?></title>
</head>
<body>
    <h2>Bonjour <?php echo e($quote->company->name ?? 'Client'); ?>,</h2>

    <?php if($customMessage): ?>
        <p><?php echo e($customMessage); ?></p>
    <?php else: ?>
        <p>Suite à votre demande, nous avons le plaisir de vous transmettre notre proposition commerciale.</p>
    <?php endif; ?>

    <p><strong>Devis n° :</strong> <?php echo e($quote->quote_number); ?></p>

    <?php if($quote->vehicles->isNotEmpty()): ?>
        <p><strong>Véhicule(s) concerné(s) :</strong> <?php echo e($quote->vehicles->pluck('license_plate')->implode(', ')); ?></p>
    <?php endif; ?>

    <?php if($quote->valid_until): ?>
        <p><strong>Valable jusqu'au :</strong> <?php echo e(\Carbon\Carbon::parse($quote->valid_until)->format('d/m/Y')); ?></p>
    <?php endif; ?>

    <table cellpadding="8" cellspacing="0" style="border-collapse: collapse; width: 100%; margin-top: 16px;">
        <thead>
            <tr style="background-color: #1a1831; color: #ffffff; text-align: left;">
                <th>Description</th>
                <th>Qté</th>
                <th>Prix unitaire</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $quote->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr style="border-bottom: 1px solid #e2e8f0;">
                    <td><?php echo e($item->description); ?></td>
                    <td><?php echo e($item->quantity); ?></td>
                    <td><?php echo e(number_format($item->price, 0, ',', ' ')); ?> XOF</td>
                    <td><?php echo e(number_format($item->price * $item->quantity, 0, ',', ' ')); ?> XOF</td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <p style="margin-top: 16px; font-size: 16px;"><strong>Montant total : <?php echo e(number_format($quote->total_amount, 0, ',', ' ')); ?> XOF</strong></p>

    <p style="margin-top: 24px;">
        Pour accepter ou refuser ce devis, connectez-vous à votre espace client :
        <a href="<?php echo e($frontendUrl); ?>/client/quotes"><?php echo e($frontendUrl); ?>/client/quotes</a>
    </p>

    <br>
    <p>Cordialement,</p>
    <p>L'équipe commerciale Mayelia — Fidelis Plus</p>
</body>
</html>
<?php /**PATH C:\Users\USER2\.gemini\antigravity\scratch\fidlisSass\fidelis_plus\resources\views/emails/quote_sent.blade.php ENDPATH**/ ?>