<!DOCTYPE html>
<html>
<head>
    <title>Bon pour accord reçu</title>
</head>
<body>
    <h2>Bonjour <?php echo e($commercial->first_name ?? $commercial->name ?? 'Commercial'); ?>,</h2>

    <p>Le client <strong><?php echo e($quote->company->name ?? 'Inconnu'); ?></strong> vient de transmettre le bon pour accord du devis <strong><?php echo e($quote->quote_number); ?></strong>.</p>

    <p>Le document est joint à cet email. Merci de l'analyser puis de mettre à jour le statut du devis (Accepter ou Refuser) depuis l'application.</p>

    <p style="margin-top: 24px;">
        <a href="<?php echo e($frontendUrl); ?>/vente"><?php echo e($frontendUrl); ?>/vente</a>
    </p>

    <br>
    <p>Cordialement,</p>
    <p>L'équipe Fidelis Plus</p>
</body>
</html>
<?php /**PATH C:\Users\USER2\.gemini\antigravity\scratch\fidlisSass\fidelis_plus\resources\views/emails/bon_pour_accord_received.blade.php ENDPATH**/ ?>