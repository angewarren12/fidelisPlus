<div <?php echo e($attributes->merge(['class' => "h-0 w-full relative"])); ?>>
    <div class="absolute top-[-1px] left-0 right-0 bottom-0 border-t border-dashed border-neutral-300 dark:border-white/[9%]"></div>
</div>
<?php /**PATH C:\Users\USER2\.gemini\antigravity\scratch\fidlisSass\fidelis_plus\vendor\laravel\framework\src\Illuminate\Foundation\Providers/../resources/exceptions/renderer/components/separator.blade.php ENDPATH**/ ?>