<!DOCTYPE html>
<html>
<head>
    <title>Nouvelle demande de devis</title>
</head>
<body>
    <h2>Bonjour <?php echo e($commercial->name ?? 'Commercial'); ?>,</h2>
    
    <p>Une nouvelle demande de devis a été soumise par votre client <strong><?php echo e($quoteRequest->company->name ?? 'Inconnu'); ?></strong>.</p>
    
    <p><strong>Véhicule concerné :</strong> <?php echo e($quoteRequest->vehicles->pluck('license_plate')->implode(', ')); ?></p>
    
    <?php if($quoteRequest->notes): ?>
        <p><strong>Notes du client :</strong> <?php echo e($quoteRequest->notes); ?></p>
    <?php endif; ?>
    
    <p>Veuillez vous connecter à l'interface d'administration pour traiter cette demande et générer le devis correspondant.</p>
    
    <br>
    <p>Cordialement,</p>
    <p>L'équipe Fidelis Plus</p>
</body>
</html>
<?php /**PATH C:\Users\USER2\.gemini\antigravity\scratch\fidlisSass\fidelis_plus\resources\views/emails/quote_request_created.blade.php ENDPATH**/ ?>