<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
    @page { margin: 0; }
    body { margin: 0; padding: 0; }
    .card {
        position: relative;
        width: 242.65pt;
        height: 153.07pt;
        overflow: hidden;
        page-break-after: always;
    }
    .card:last-child { page-break-after: auto; }
    .card img.bg {
        position: absolute;
        top: 0; left: 0;
        width: 100%;
        height: 100%;
    }
    .card img.qr {
        position: absolute;
        background: #fff;
        padding: 2pt;
    }
    .card .card-number {
        position: absolute;
        font-family: 'Courier New', monospace;
        font-weight: bold;
    }
    .card .holder-name {
        position: absolute;
        font-family: Helvetica, Arial, sans-serif;
        font-weight: bold;
        white-space: nowrap;
    }
</style>
</head>
<body>
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card">
        <?php if($backgroundDataUri): ?>
            <img class="bg" src="<?php echo e($backgroundDataUri); ?>">
        <?php endif; ?>
        <img class="qr"
             src="<?php echo e($item['qr_data_uri']); ?>"
             style="left: <?php echo e($layout['qr_x']); ?>%; top: <?php echo e($layout['qr_y']); ?>%; width: <?php echo e($layout['qr_size']); ?>%;">
        <div class="card-number"
             style="left: <?php echo e($layout['card_number_x']); ?>%; top: <?php echo e($layout['card_number_y']); ?>%; color: <?php echo e($layout['card_number_color']); ?>; font-size: <?php echo e($layout['card_number_size']); ?>px;">
            N° <?php echo e($item['card_number']); ?>

        </div>
        <?php if(!empty($layout['holder_name_enabled']) && !empty($item['holder_name'])): ?>
            <div class="holder-name"
                 style="left: <?php echo e($layout['holder_name_x'] ?? 8); ?>%; top: <?php echo e($layout['holder_name_y'] ?? 75); ?>%; color: <?php echo e($layout['holder_name_color'] ?? '#ffffff'); ?>; font-size: <?php echo e($layout['holder_name_size'] ?? 11); ?>px;">
                <?php echo e($item['holder_name']); ?>

            </div>
        <?php endif; ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html>
<?php /**PATH C:\Users\USER2\.gemini\antigravity\scratch\fidlisSass\fidelis_plus\resources\views/loyalty/card-batch-pdf.blade.php ENDPATH**/ ?>